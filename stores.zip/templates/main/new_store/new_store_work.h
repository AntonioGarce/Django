{% include "header.html" %} {% autoescape off %}


{% include "main/new_store/new_store_asset.html" %}

<section class="product-area li-laptop-product pt-30">
<div class="container">
<div class="row">
<div class="col-lg-12">
<div class="li-section-title">
<h2><span> Работа
</span></h2>
</div>
<div class="p-3">
 <pre style="font-weight: normal;
    font-size: initial; font-family: sans-serif;">{{ store.work }}️</pre>
</div>
</div>
</div>
</div>
</section>
</div>
</div>
</div>

</div>


{% endautoescape %}{% include "footer.html" %}