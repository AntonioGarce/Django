from django.contrib import admin
from .models import Site_handlers
# Register your models here.
admin.site.register(Site_handlers)
