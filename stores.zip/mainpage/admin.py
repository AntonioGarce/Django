from django.contrib import admin
from .models import *
from dynamic_admin_forms.admin import DynamicModelAdminMixin
from django.contrib.admin.widgets import AdminTextInputWidget
from item_s.models import Location, GoodLocation
# Register your models here.
